from flask import Flask, request, send_file, jsonify, session
from flask_bcrypt import Bcrypt
from flask_cors import CORS, cross_origin
from flask_session import Session
from config import ApplicationConfig
from models import db
import db_connector
import os
import locale
locale.setlocale(locale.LC_ALL, 'en_US.utf8')

app = Flask(__name__)
app.config.from_object(ApplicationConfig)
db.init_app(app)
from models import User
with app.app_context():
    db.create_all()
    db.session.commit()
bcrypt = Bcrypt(app)
CORS(app, supports_credentials=True)
server_session = Session(app)

port = os.getenv("PORT")


@app.route("/me")
def get_current_user():
    try:
        user_id = session.get("user_id")

        if not user_id:
            return jsonify({"error": "Unauthorized"}), 401

        user = User.query.filter_by(id=user_id).first()
        return jsonify(
            {
                "success": True,
                "message": "User validated",
                "error_code": 0,
                "data": {
                    "id": user.id,
                    "email": user.email
                }
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while fetching current user : {}".format(er)}), 500


@app.route("/signup", methods=["POST"])
def register_user():
    try:
        email = request.json["email"]
        password = request.json["password"]

        user_exists = User.query.filter_by(email=email).first() is not None

        if user_exists:
            return jsonify({"error": "User already exists"}), 409

        hashed_password = bcrypt.generate_password_hash(password)
        new_user = User(email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        session["user_id"] = new_user.id

        return jsonify(
            {
                "success": True,
                "message": "Signup Successful",
                "error_code": 0,
                "data": {
                    "id": new_user.id,
                    "email": new_user.email
                }
            }), 200

    except Exception as er:
        return jsonify({"error": "Error while signing up : {}".format(er)}), 500


@app.route("/login", methods=["POST"])
def login_user():
    try:
        email = request.json["email"]
        password = request.json["password"]

        user = User.query.filter_by(email=email).first()

        if user is None:
            return jsonify({"error": "Unauthorized"}), 200

        if not bcrypt.check_password_hash(user.password, password):
            return jsonify({"error": "Unauthorized"}), 200

        session["user_id"] = user.id

        return jsonify(
            {
                "success": True,
                "message": "Login Successful",
                "error_code": 0,
                "data": {
                    "id": user.id,
                    "email": user.email
                }
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while logging in : {}".format(er)}), 500
        
        
def create_table():
    
    #try:
        table = db_connector.create_table()
        return True
    #except Exception as er:
     #   print(er)
      #  return False


@app.route("/logout", methods=["POST"])
def logout_user():
    try:
        session.pop("user_id")
        session.clear()
        return jsonify(
            {
                "success": True,
                "message": "Logout Successful",
                "error_code": 0

            }), 200
    except Exception as er:
        return jsonify({"error": "Error while logging out : {}".format(er)}), 500


@app.route("/project_list", methods=["GET"])
def get_project_list():
    try:
        project_list = db_connector.get_project_list()
        return jsonify(
            {
                "success": True,
                "message": "Fetching Project list Successful ",
                "error_code": 0,
                "data": project_list
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Fetching project list : {}".format(er)}), 500


@app.route("/get_milestone_date", methods=["GET"])
def get_milestone_dates():
    try:
        milestone_dates = db_connector.get_milestones()
        return jsonify(
            {
                "success": True,
                "message": "Fetching Milestone dates Successful ",
                "error_code": 0,
                "data": milestone_dates
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Fetching Milestone dates : {}".format(er)}), 500


@app.route("/filter_milestone", methods=["POST"])
def filter_milestone():
    try:
        project_id = request.json["project_id"]
        mode = request.json["mode"]
        filter_milestone_dates = db_connector.filter_milestones(project_id, mode)
        return jsonify(
            {
                "success": True,
                "message": "Fetching Milestone data Successful ",
                "error_code": 0,
                "data": filter_milestone_dates
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Fetching Milestone data : {}".format(er)}), 500


@app.route("/filter_records", methods=["POST"])
def filter_records():
    try:
        project_id = request.json["project_id"]
        function = request.json["function"]
        mode = request.json["mode"]
        filtered_records = db_connector.filter_record(project_id=project_id, function=function, mode=mode)
        return jsonify(
            {
                "success": True,
                "message": "Fetching Filtered records Successful.",
                "error_code": 0,
                "data": filtered_records
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Fetching Filtered records : {}".format(er)}), 500


@app.route("/get_dev", methods=["GET"])
def get_dev_records():
    try:
        dev_records = db_connector.get_records("Development")
        return jsonify(
            {
                "success": True,
                "message": "Fetching Development records Successful ",
                "error_code": 0,
                "data": dev_records
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Fetching Development records : {}".format(er)}), 500


@app.route("/get_hor", methods=["GET"])
def get_hor_records():
    try:
        hor_records = db_connector.get_records("Horizontal")
        return jsonify(
            {
                "success": True,
                "message": "Fetching Horizontal records Successful ",
                "error_code": 0,
                "data": hor_records
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Fetching Horizontal records : {}".format(er)}), 500


@app.route("/get_val", methods=["GET"])
def get_val_records():
    try:
        val_records = db_connector.get_records("Validation")
        return jsonify(
            {
                "success": True,
                "message": "Fetching Validation records Successful ",
                "error_code": 0,
                "data": val_records
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Fetching Validation records : {}".format(er)}), 500


@app.route("/insert_milestone_date", methods=["POST"])
def insert_milestone_dates():
    try:
        project_id = request.json["project_id"]
        mode = request.json["mode"]
        popl_2 = request.json["popl_2"]
        popl_3 = request.json["popl_3"]
        po = request.json["po"]
        es = request.json["es"]
        ao = request.json["ao"]
        bo = request.json["bo"]
        alpha = request.json["alpha"]
        beta = request.json["beta"]
        prq = request.json["prq"]
        pv = request.json["pv"]
        db_connector.insert_milestones(project_id, mode, popl_2, popl_3, po, es, ao, bo, alpha, beta, prq, pv)
        return jsonify(
            {
                "success": True,
                "message": "Inserting Milestone dates Successful ",
                "error_code": 0
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Inserting Milestone dates : {}".format(er)}), 500


@app.route("/insert_update_milestone_date", methods=["POST"])
def insert_update_milestone_dates():
    try:
        milestone_id = request.json["milestone_id"]
        project_id = request.json["project_id"]
        mode = request.json["mode"]
        popl_2 = request.json["popl_2"]
        popl_3 = request.json["popl_3"]
        po = request.json["po"]
        es = request.json["es"]
        ao = request.json["ao"]
        bo = request.json["bo"]
        alpha = request.json["alpha"]
        beta = request.json["beta"]
        prq = request.json["prq"]
        pv = request.json["pv"]
        db_connector.insert_update_milestones(milestone_id, project_id, mode, popl_2, popl_3, po, es, ao, bo,
                                              alpha, beta, prq, pv)
        return jsonify(
            {
                "success": True,
                "message": "Updating Milestone dates Successful ",
                "error_code": 0
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Updating Milestone dates : {}".format(er)}), 500


@app.route("/insert_update_records", methods=["POST"])
def insert_update_record():
    try:
        data = request.json["data"]
        for record in data:
            db_connector.insert_update_records(record_id=record["record_id"], project_id=record["project_id"],
                                               features=record["features"], feature_owner=record["feature_owner"],
                                               function=record["function"], domain=record["domain"],
                                               status=record["status"], mode=record["mode"],
                                               milestone=record["milestone"], function_owner=record["function_owner"],
                                               estimation_type=record["estimation_type"],
                                               q1=record["q1"], q2=record["q2"], q3=record["q3"], q4=record["q4"],
                                               q5=record["q5"], q6=record["q6"], q7=record["q7"], q8=record["q8"],
                                               q9=record["q9"], q10=record["q10"], q11=record["q11"],
                                               q12=record["q12"], q13=record["q13"])
        return jsonify(
            {
                "success": True,
                "message": "Record Update successful Successful ",
                "error_code": 0
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Updating records : {}".format(er)}), 500


@app.route("/get_budget", methods=["POST"])
def get_budgets():
    try:
        project_id = request.json["project_id"]
        budget_dict = db_connector.get_budget(project_id)
        if "total" in  budget_dict:
            for i in budget_dict["total"]:
                 price = budget_dict["total"][i]
               
                 budget_dict["total"][i]= locale.currency(price, grouping = True)
                   
        return jsonify(
            {
                "success": True,
                "message": "Fetching Budget data Successful ",
                "error_code": 0,
                "data": budget_dict
            }), 200
    except Exception as er:
        return jsonify({"error": "Error while Fetching Budget data : {}".format(er)}), 500


@app.route('/download')
def download_file():
    path = "report//1773-Book3.xlsx"
    return send_file(path, as_attachment=True)


if __name__ == "__main__":
    crt_table = create_table()
     # If the app is running locally
    if port is None:
        app.run(host='0.0.0.0',port =5001)
    else:
        # Else use cloud foundry default port
        app.run(host='0.0.0.0', port=int(port), debug=False)
    
