import sqlite3
import json
import collections
import pandas as pd


conn = sqlite3.connect("planner.sqlite", check_same_thread=False)

cursor = conn.cursor()





#data_milestone = pd.read_csv('milestone.csv')
#data_milestone.to_sql('milestone', conn, if_exists='append', index=False)
#get_milestone_query = 'SELECT * FROM milestone'
#cursor.execute(get_milestone_query)

create_project = """ CREATE TABLE IF NOT EXISTS project (
    project_id   INTEGER PRIMARY KEY
                         NOT NULL
                         UNIQUE,
    project_name TEXT    NOT NULL,
    st_month     TEXT,
    end_month    TEXT,
    end_year     TEXT
)"""

create_project_features = """ CREATE TABLE IF NOT EXISTS project_features (
    project_feature_id integer PRIMARY KEY,
    project_id int NOT NULL ,
    feature_owner text NOT NULL,
    function_id text NOT NULL,
    domain_id text NOT NULL,
    feature_id text NOT NULL,
    feature_status text NOT NULL,
    model_id text NOT NULL,
    FOREIGN KEY(project_id) REFERENCES project(project_id)
)"""

create_hc_record = """ CREATE TABLE IF NOT EXISTS hc_record (
    project_feature_id integer PRIMARY KEY,
    milestone_id text NOT NULL,
    quarter text NOT NULL,
    year text NOT NULL,
    hc_val text NOT NULL,
    FOREIGN KEY(project_feature_id) REFERENCES project_features(project_feature_id)
)"""

create_function = """ CREATE TABLE IF NOT EXISTS function (
    function_id integer PRIMARY KEY,
    function_name text NOT NULL
)"""

create_domain = """ CREATE TABLE IF NOT EXISTS domain (
    domain_id integer PRIMARY KEY,
    domain_name text NOT NULL,
    domain_owner text NOT NULL
)"""

create_features = """ CREATE TABLE IF NOT EXISTS features (
    feature_id integer PRIMARY KEY,
    domain_id integer NOT NULL,
    feature_name text NOT NULL,
    feature_owner text NOT NULL,
    FOREIGN KEY(domain_id) REFERENCES domain(domain_id)
)"""

create_models = """ CREATE TABLE IF NOT EXISTS models (
    model_id integer PRIMARY KEY,
    model_name text NOT NULL

)"""

create_milestone = """ CREATE TABLE IF NOT EXISTS milestone (
    milestone_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    project_id INTEGER    NOT NULL,
    mode         TEXT,
    popl_2       TEXT,
    popl_3       TEXT,
    po           TEXT,
    es           TEXT,
    ao           TEXT,
    bo           TEXT,
    alpha        TEXT,
    beta         TEXT,
    prq          TEXT,
    pv           TEXT,
    FOREIGN KEY(project_id) REFERENCES project(project_id)
)"""

create_record = """ CREATE TABLE IF NOT EXISTS record (
    record_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    project_id int NOT NULL,
    features     TEXT,
    feature_owner TEXT,
    function    TEXT,
    domain    TEXT,
    status    TEXT,
    mode    TEXT,
    milestone    TEXT,
    date    TEXT,
    category    TEXT,
    function_owner    TEXT,
    estimation_type    TEXT,
    q1    DOUBLE,
    q2    DOUBLE,
    q3    DOUBLE,
    q4    DOUBLE,
    q5    DOUBLE,
    q6    DOUBLE,
    q7    DOUBLE,
    q8    DOUBLE,
    q9    DOUBLE,
    q10   DOUBLE,
    q11   DOUBLE,
    q12   BOOLEAN,
    q13   BOOLEAN,
    total_till_prq  DOUBLE,
    FOREIGN KEY(project_id) REFERENCES project(project_id)
);"""



def create_table():
    cursor.execute(create_project)
    conn.commit()
    data_project = pd.read_csv('project.csv')
    data_project.to_sql('project', conn, if_exists='replace', index=False)
    cursor.execute(create_project_features)
    conn.commit()
    cursor.execute(create_hc_record)
    conn.commit()
    cursor.execute(create_function)
    conn.commit()
    cursor.execute(create_domain)
    conn.commit()
    cursor.execute(create_features)
    conn.commit()
    cursor.execute(create_models)
    conn.commit()
    cursor.execute(create_milestone)
    conn.commit()
    data_milestone = pd.read_csv('milestone.csv')
    data_milestone.to_sql('milestone', conn, if_exists='replace', index=False)
    # import pdb
    # pdb.set_trace()
    cursor.execute(create_record)
    conn.commit()
    data_record = pd.read_csv('data.csv')
    data_record.to_sql('record', conn, if_exists='replace', index=False)

#create_table()


def get_project_list():
    get_project_query = """ SELECT project_id, project_name FROM project """
    cursor.execute(get_project_query)
    records = cursor.fetchall()
    objects_list = []
    for row in records:
        d = dict()
        d['project_id'] = row[0]
        d['project_name'] = row[1]
        objects_list.append(d)
    # project_list = json.dumps(objects_list)
    return objects_list


# print(get_project_list())
# get_project_list()


def get_records(function):
    get_records_query = """SELECT * FROM record 
                            WHERE function = '{filter}'""".format(filter=function)
    cursor.execute(get_records_query)
    records = cursor.fetchall()
    objects_list = []
    print(records)
    for row in records:
        d = dict()
        d['record_id'] = row[0]
        d['project_id'] = row[1]
        d['features'] = row[2]
        d['feature_owner'] = row[3]
        d['function'] = row[4]
        d['domain'] = row[5]
        d['status'] = row[6]
        d['mode'] = row[7]
        d['milestone'] = row[8]
        d['function_owner'] = row[9]
        d['estimation_type'] = row[10]
        d['q1'] = row[11]
        d['q2'] = row[12]
        d['q3'] = row[13]
        d['q4'] = row[14]
        d['q5'] = row[15]
        d['q6'] = row[16]
        d['q7'] = row[17]
        d['q8'] = row[18]
        d['q9'] = row[19]
        d['q10'] = row[20]
        d['q11'] = row[21]
        d['q12'] = row[22]
        d['q13'] = row[23]
        d['total_till_prq'] = row[24]
        objects_list.append(d)
    return objects_list


def get_milestones():
    get_milestones_query = """ SELECT * FROM milestone"""
    cursor.execute(get_milestones_query)
    records = cursor.fetchall()
    objects_list = []
    for row in records:
        d = dict()
        d['milestone_id'] = row[0]
        d['project_id'] = row[1]
        d['mode'] = row[2]
        d['popl_2'] = row[3]
        d['popl_3'] = row[4]
        d['po'] = row[5]
        d['es'] = row[6]
        d['ao'] = row[7]
        d['bo'] = row[8]
        d['alpha'] = row[9]
        d['beta'] = row[10]
        d['prq'] = row[11]
        d['pv'] = row[12]
        objects_list.append(d)
    return objects_list


def filter_milestones(project_id, mode):
    filter_milestones_query = """ SELECT * FROM milestone 
    WHERE project_id ='{project_id}' AND mode = '{mode}'""".format(project_id=project_id, mode=mode)
    cursor.execute(filter_milestones_query)
    records = cursor.fetchall()
    objects_list = []
    for row in records:
        d = dict()
        d['milestone_id'] = row[0]
        d['project_id'] = row[1]
        d['mode'] = row[2]
        d['popl_2'] = row[3]
        d['popl_3'] = row[4]
        d['po'] = row[5]
        d['es'] = row[6]
        d['ao'] = row[7]
        d['bo'] = row[8]
        d['alpha'] = row[9]
        d['beta'] = row[10]
        d['prq'] = row[11]
        d['pv'] = row[12]
        objects_list.append(d)
    return objects_list


def filter_record(project_id, function, mode):
    get_records_query = """SELECT * FROM record 
                            WHERE project_id = '{project_id}' AND function = '{function}' AND mode = '{mode}'""".format(
        project_id=project_id, function=function, mode=mode)
    cursor.execute(get_records_query)
    records = cursor.fetchall()
    objects_list = []
    print(records)
    for row in records:
        d = dict()
        d['record_id'] = row[0]
        d['project_id'] = row[1]
        d['features'] = row[2]
        d['feature_owner'] = row[3]
        d['function'] = row[4]
        d['domain'] = row[5]
        d['status'] = row[6]
        d['mode'] = row[7]
        d['milestone'] = row[8]
        d['function_owner'] = row[9]
        d['estimation_type'] = row[10]
        d['q1'] = row[11]
        d['q2'] = row[12]
        d['q3'] = row[13]
        d['q4'] = row[14]
        d['q5'] = row[15]
        d['q6'] = row[16]
        d['q7'] = row[17]
        d['q8'] = row[18]
        d['q9'] = row[19]
        d['q10'] = row[20]
        d['q11'] = row[21]
        d['q12'] = row[22]
        d['q13'] = row[23]
        d['total_till_prq'] = row[24]
        objects_list.append(d)
    return objects_list


def insert_milestones(project_id, mode, popl_2, popl_3, po, es, ao, bo, alpha, beta, prq, pv):
    insert_milestones_query = '''INSERT INTO milestone(
        project_id, mode, popl_2, popl_3, po, es, ao, bo, alpha, beta, prq, pv) VALUES 
       ('{project_id}', '{mode}', '{popl_2}', '{popl_3}', '{po}','{es}', '{ao}', '{bo}', '{alpha}',
        '{beta}', '{prq}', '{pv}');'''.format(project_id=project_id, mode=mode, popl_2=popl_2,
                                              popl_3=popl_3, po=po, es=es, ao=ao, bo=bo, alpha=alpha, beta=beta,
                                              prq=prq, pv=pv)


    cursor.execute(insert_milestones_query)
    conn.commit()


def insert_update_milestones(milestone_id, project_id, mode, popl_2, popl_3, po, es, ao, bo, alpha, beta, prq, pv):
    insert_milestones_query = '''INSERT INTO milestone(
        project_id, mode, popl_2, popl_3, po, es, ao, bo, alpha, beta, prq, pv) VALUES 
       ('{project_id}', '{mode}', '{popl_2}', '{popl_3}', '{po}','{es}', '{ao}', '{bo}', '{alpha}',
        '{beta}', '{prq}', '{pv}');'''.format(project_id=project_id, mode=mode, popl_2=popl_2,
                                              popl_3=popl_3, po=po, es=es, ao=ao, bo=bo, alpha=alpha, beta=beta,
                                              prq=prq, pv=pv)

    update_milestones_query = '''UPDATE milestone set
         project_id = '{project_id}', mode='{mode}', popl_2='{popl_2}', popl_3='{popl_3}', po='{po}', es='{es}',
         ao='{ao}', bo='{bo}', alpha='{alpha}', beta='{beta}', prq='{prq}', pv='{pv}' 
         WHERE milestone_id = {milestone_id}
       '''.format(milestone_id=milestone_id, project_id=project_id, mode=mode, popl_2=popl_2,
                                              popl_3=popl_3, po=po, es=es, ao=ao, bo=bo, alpha=alpha, beta=beta,
                                              prq=prq, pv=pv)
    if milestone_id:
        cursor.execute(update_milestones_query)
        conn.commit()
    else:
        cursor.execute(insert_milestones_query)
        conn.commit()


def insert_update_records(record_id, project_id, features, feature_owner, function, domain, status, mode, milestone,
                          function_owner, estimation_type, q1=0, q2=0, q3=0, q4=0, q5=0, q6=0, q7=0,
                          q8=0, q9=0, q10=0, q11=0, q12=0, q13=0):
    insert_records_query = '''INSERT OR IGNORE INTO record(project_id,features,feature_owner,function,domain,status,
    mode,milestone,function_owner,estimation_type,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12,q13) VALUES 
       ('{project_id}','{features}','{feature_owner}','{function}','{domain}','{status}','{mode}','{milestone}',
       '{function_owner}','{estimation_type}','{q1}','{q2}','{q3}','{q4}','{q5}','{q6}','{q7}','{q8}','{q9}','{q10}',
       '{q11}','{q12}','{q13}');'''.format(project_id=project_id, features=features, feature_owner=feature_owner,
                                           function=function,
                                           domain=domain, status=status, mode=mode, milestone=milestone,
                                           function_owner=function_owner, estimation_type=estimation_type, q1=q1,
                                           q2=q2, q3=q3, q4=q4, q5=q5, q6=q6, q7=q7, q8=q8, q9=q9, q10=q10, q11=q11,
                                           q12=q12, q13=q13)
    update_records_query = '''UPDATE record set project_id = '{project_id}', features = '{features}',
    feature_owner = '{feature_owner}',function = '{function}',domain = '{domain}', status = '{status}',mode = '{mode}',
    milestone = '{milestone}', function_owner = '{function_owner}',estimation_type = '{estimation_type}',
    q1 = '{q1}',q2 = '{q2}',q3 = '{q3}',q4 = '{q4}',q5 = '{q5}',q6 = '{q6}',q7 = '{q7}',q8 = '{q8}',q9 = '{q9}',
    q10 = '{q10}',q11 = '{q11}',q12 = '{q12}',q13 = '{q13}'
    WHERE record_id = {record_id} '''.format(record_id=record_id, project_id=project_id, features=features,
                                             feature_owner=feature_owner, function=function, domain=domain,
                                             status=status, mode=mode, milestone=milestone,
                                             function_owner=function_owner, estimation_type=estimation_type,
                                             q1=q1, q2=q2, q3=q3, q4=q4, q5=q5, q6=q6, q7=q7, q8=q8, q9=q9, q10=q10,
                                             q11=q11, q12=q12, q13=q13)
    if record_id:
        cursor.execute(update_records_query)
        conn.commit()
    else:
        cursor.execute(insert_records_query)
        conn.commit()


def get_budget(project_id):
    usa_avg_burdn = 56.23
    penang_avg_burdn = 13.1925
    india_avg_burdn = 18.705
    usa_gio_percent = 0.2
    penang_gio_percent = 0.4
    india_gio_percent = 0.4
    multi_factor = (usa_avg_burdn * usa_gio_percent +
                                      penang_avg_burdn * penang_gio_percent +
                                      india_avg_burdn * india_gio_percent)
    get_budget_hc_query = """SELECT function, SUM(total_till_prq) FROM record 
                        WHERE project_id = '{project_id}' AND estimation_type = '{estimation_type}'
                        GROUP BY function """.format(
        project_id=project_id, estimation_type="HC")
    cursor.execute(get_budget_hc_query)
    hc_records = cursor.fetchall()
    hc_dict = dict(hc_records)
    for key in hc_dict:
        hc_dict[key] = round(hc_dict[key]*multi_factor, 2)
    get_budget_bti_query = """SELECT function, SUM(total_till_prq) FROM record 
                        WHERE project_id = '{project_id}' AND estimation_type = '{estimation_type}'
                        GROUP BY function """.format(
        project_id=project_id, estimation_type="BTI")
    cursor.execute(get_budget_bti_query)
    bti_records = cursor.fetchall()
    bti_dict = dict(bti_records)
    budget_dict = dict()
    total = dict()
    budget_dict['HC'] = hc_dict
    budget_dict['BTI'] = bti_dict
    total['HC'] = sum(hc_dict.values())
    total['BTI'] = sum(bti_dict.values())
    budget_dict['total'] = total
    return budget_dict

